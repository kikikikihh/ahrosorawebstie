# Deploy to GitHub Pages: ahrosorashop.com

This folder is a zero-build static site, so GitHub Pages can serve it for free with HTTPS.
No Python, no Node.js, and no database are required.

If you follow this guide exactly, **https://ahrosorashop.com/** will work.

---

## 0) What you need

- A GitHub account (https://github.com)
- This folder: `C:\Users\starter!\Documents\Default Project`
- The domain `ahrosorashop.com` — already bought, and you can edit its DNS
- About 10 minutes + DNS propagation time (usually 5–60 minutes)

---

## 1) What is already ready in this folder

- `CNAME` (content: `ahrosorashop.com`) — GitHub Pages reads this to know the custom domain
- `index.html`, `store.html`, `rules.html`, `support.html`, `404.html`
- `assets/`, `css/`, `js/` — images and styles
- `sitemap.xml`, `robots.txt`, `.nojekyll`, `README.md`

**Do not delete or rename `CNAME`.** It must match your domain exactly (no `https://`, no slashes).

---

## 2) Create a GitHub repository

1. Go to https://github.com/new
2. Repository name: e.g. `ahrosorashop` (any name is fine)
3. **Public** is fine for a public website
4. **Do NOT** check "Initialize this repository with a README"
   (this folder already has everything)
5. Click **Create repository**
6. GitHub shows the URL, for example:
   `https://github.com/johndoe/ahrosorashop.git`
   → copy your URL

---

## 3) Push the site to GitHub

Open **PowerShell** and run:

```powershell
cd "C:\Users\starter!\Documents\Default Project"
git init
git add .
git commit -m "Prepare ahrosorashop.com"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo>.git
git push -u origin main
```

Replace `<your-username>` and `<repo>` with your real values, for example:

```powershell
git remote add origin https://github.com/johndoe/ahrosorashop.git
```

If PowerShell opens a window/browser asking you to sign in to GitHub — sign in.

---

## 4) Enable GitHub Pages

1. On GitHub, open your repository
2. **Settings** → **Pages** (left sidebar)
3. Under **Build and deployment**:
   - **Source**: `Deploy from a branch`
   - **Branch**: `main`
   - **Folder**: `/ (root)`
   - Click **Save**
4. Wait 1–2 minutes
5. In the same **Pages** screen, under **Custom domain**, type:
   `ahrosorashop.com`
   and click **Save**

---

## 5) Point the domain to GitHub Pages (DNS)

Go to your domain control panel (registrar or DNS provider), then add:

### Apex domain: `ahrosorashop.com`

**4 × `A` records** — host `@` pointing to:

| Host | Type | Value |
|------|------|-------|
| @ | A | 185.199.108.153 |
| @ | A | 185.199.109.153 |
| @ | A | 185.199.110.153 |
| @ | A | 185.199.111.153 |

Optional **4 × `AAAA` records**:

| Host | Type | Value |
|------|------|-------|
| @ | AAAA | 2606:50c0:8000::153 |
| @ | AAAA | 2606:50c0:8001::153 |
| @ | AAAA | 2606:50c0:8002::153 |
| @ | AAAA | 2606:50c0:8003::153 |

### Subdomain: `www.ahrosorashop.com`

| Host | Type | Value |
|------|------|-------|
| www | CNAME | `<your-github-username>.github.io` |

For example: `johndoe.github.io` (replace with your username).

### Clean up

Delete any of these if they exist:
- registrar "parking" A records
- wildcard `*` record
- old GitHub / Cloudflare records from another site

**If you use Cloudflare as DNS proxy:** set the `www` CNAME to **DNS only** (grey cloud) until HTTPS works.
Leave the apex `A` records as plain DNS as well.

---

## 6) Wait for DNS

### Check from PowerShell

```powershell
Resolve-DnsName ahrosorashop.com
Resolve-DnsName www.ahrosorashop.com
```

Expected `A` records should list `185.199.108.153`, `.109.153`, `.110.153`, `.111.153`.
If you see "DNS name does not exist", records are not added yet or not propagated.

### Check public DNS (independent of your PC)

```powershell
curl.exe "https://cloudflare-dns.com/dns-query?name=ahrosorashop.com&type=A" -H "accept: application/dns-json"
curl.exe "https://cloudflare-dns.com/dns-query?name=www.ahrosorashop.com&type=CNAME" -H "accept: application/dns-json"
```

`"Status":0` means the domain resolves. `"Status":3` means NXDOMAIN (not set yet).

---

## 7) Turn on HTTPS

1. Go back to GitHub → your repo → **Settings → Pages**
2. Wait until the domain shows a green tick / "DNS check successful"
3. Check **Enforce HTTPS**
4. Wait for GitHub to issue the certificate (usually minutes; up to 24h)

---

## 8) Verify the live site

Open these and check each loads with a padlock in the address bar:

| What | URL |
|------|-----|
| Home | https://ahrosorashop.com/ |
| Store | https://ahrosorashop.com/store.html |
| Rules | https://ahrosorashop.com/rules.html |
| Support | https://ahrosorashop.com/support.html |
| 404 page | https://ahrosorashop.com/404.html |
| Sitemap | https://ahrosorashop.com/sitemap.xml |
| `www` version | https://www.ahrosorashop.com/ |

Both apex and `www` will show the same site. If you want exactly one canonical address
(your current canonical/OG tags and `CNAME` are `ahrosorashop.com`), that is already set — no extra work needed for the site itself.
Redirecting `www` → apex at the edge (e.g. Cloudflare Rules) is optional and only affects SEO polish.

---

## 9) After it works

- Submit `https://ahrosorashop.com/sitemap.xml` in Google Search Console
- Test a copy button and the store checkout once more on the live site
- Old domain: **`luymea.com` will no longer serve this site** because `CNAME` changed.
  If you still want old traffic to reach the new site, use a Cloudflare redirect/bulk redirect
  from `luymea.com` → `https://ahrosorashop.com`, or keep a separate small repo/site for it.

---

## 10) If something breaks

| Problem | Fix |
|---------|-----|
| GitHub shows "improperly configured" for custom domain | Wait for DNS propagation, then remove and re-add `ahrosorashop.com` in **Settings → Pages** |
| "Enforce HTTPS" is greyed out | DNS not correct yet; check apex `A` records and `www` CNAME |
| 404 error on GitHub Pages | Check repo **Settings → Pages** → branch = `main`, folder = `/ (root)`; root must contain `index.html` |
| Wrong files / mixed styling | Verify images/CSS were committed; check the Files pane on GitHub — `assets/`, `css/`, `js/` must be there |
| Cloudflare orange cloud | Set `www` CNAME to DNS only (grey cloud) until HTTPS works |
| Checkout opens wrong Telegram | This repo was already updated to `@ahrosoragp`; verify `js/store.js` and `store.html` |
| Email links don't work | The site kept `support@luymea.com`; `ahrosorashop.com` has no MX records yet |

---

## 11) Current state of this folder (as of this guide)

- Brand: **ahrosora**
- Website: **https://ahrosorashop.com** (site metadata, `CNAME`, sitemap, robots, canonical already updated)
- Server IP: **ahrosora.paper**
- Store checkout: order is copied and sent to **@ahrosoragp**
- Email kept: **support@luymea.com** (no mail setup yet)
- Backup of pre-update files: `C:\Users\starter!\AppData\Local\Temp\opencode\website-backup-2026-11-07`
