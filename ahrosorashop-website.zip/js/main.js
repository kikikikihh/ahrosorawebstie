/* ==========================================================================
   ahrosora — shared site behaviour
   ========================================================================== */
(function () {
  "use strict";

  const toastEl = document.getElementById("toast");
  const toastText = document.getElementById("toastText");
  let toastTimer = null;

  function showToast(message, type) {
    if (!toastEl || !toastText) return;
    toastText.textContent = message;
    toastEl.classList.toggle("error", type === "error");
    const use = toastEl.querySelector("use");
    if (use) use.setAttribute("href", type === "error" ? "#i-info" : "#i-check");
    toastEl.classList.add("show");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () {
      toastEl.classList.remove("show");
    }, 3600);
  }
  window.showToast = showToast;

  async function copyText(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (err) {
      /* fall through to legacy copy */
    }
    try {
      const area = document.createElement("textarea");
      area.value = text;
      area.setAttribute("readonly", "");
      area.style.position = "fixed";
      area.style.opacity = "0";
      area.style.pointerEvents = "none";
      document.body.appendChild(area);
      area.select();
      area.setSelectionRange(0, area.value.length);
      const ok = document.execCommand("copy");
      area.remove();
      return ok;
    } catch (err) {
      return false;
    }
  }

  /* Copy IP buttons */
  document.addEventListener("click", async function (event) {
    const trigger = event.target.closest("[data-copy]");
    if (!trigger) return;
    const value = trigger.getAttribute("data-copy");
    if (!value) return;
    const ok = await copyText(value);
    if (ok) {
      showToast("បានចម្លង " + value + " — បញ្ចូលក្នុង Minecraft ឥឡូវនេះ!");
    } else {
      showToast("មិនអាចចម្លងបានទេ — សូមជ្រើសរើស និងចម្លងដោយដៃ។", "error");
    }
  });

  /* Mobile menu */
  const menuToggle = document.getElementById("menuToggle");
  const navLinks = document.getElementById("navLinks");
  if (menuToggle && navLinks) {
    menuToggle.addEventListener("click", function () {
      const open = navLinks.classList.toggle("open");
      menuToggle.setAttribute("aria-expanded", String(open));
      menuToggle.setAttribute("aria-label", open ? "បិទម៉ឺនុយ" : "បើកម៉ឺនុយ");
    });
    navLinks.addEventListener("click", function (event) {
      if (event.target.closest("a")) {
        navLinks.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
      }
    });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && navLinks.classList.contains("open")) {
        navLinks.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.focus();
      }
    });
    document.addEventListener("click", function (event) {
      if (!event.target.closest(".nav") && navLinks.classList.contains("open")) {
        navLinks.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  /* Header shadow on scroll */
  const header = document.getElementById("siteHeader");
  if (header) {
    const onScroll = function () {
      header.classList.toggle("scrolled", window.scrollY > 8);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  /* Reveal on scroll */
  const revealItems = document.querySelectorAll("[data-reveal]");
  if (revealItems.length) {
    if ("IntersectionObserver" in window) {
      const revealObserver = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              entry.target.classList.add("is-visible");
              revealObserver.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.08, rootMargin: "0px 0px -30px 0px" }
      );
      revealItems.forEach(function (item) {
        revealObserver.observe(item);
      });
    } else {
      revealItems.forEach(function (item) {
        item.classList.add("is-visible");
      });
    }
  }

  /* Footer year */
  const yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  /* Animated counters */
  const counters = document.querySelectorAll("[data-count]");
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (counters.length && !reducedMotion) {
    const animateCounter = function (el) {
      const target = parseFloat(el.getAttribute("data-count"));
      const decimals = String(el.getAttribute("data-count")).includes(".") ? 1 : 0;
      const suffix = el.getAttribute("data-count").includes(".") ? "" : "";
      const duration = 1400;
      const start = performance.now();
      const formatter = new Intl.NumberFormat("en-US", {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
      });
      function tick(now) {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        el.textContent = formatter.format(target * eased) + suffix;
        if (progress < 1) requestAnimationFrame(tick);
        else el.textContent = formatter.format(target) + suffix;
      }
      requestAnimationFrame(tick);
    };
    if ("IntersectionObserver" in window) {
      const counterObserver = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              animateCounter(entry.target);
              counterObserver.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.5 }
      );
      counters.forEach(function (el) {
        counterObserver.observe(el);
      });
    } else {
      counters.forEach(animateCounter);
    }
  }

  /* Weekly countdown — next Friday, 20:00 ICT (UTC+7) */
  const countdown = document.getElementById("countdown");
  if (countdown) {
    const daysEl = document.getElementById("cd-days");
    const hoursEl = document.getElementById("cd-hours");
    const minutesEl = document.getElementById("cd-minutes");
    const secondsEl = document.getElementById("cd-seconds");

    function nextFriday20ICT() {
      const now = new Date();
      const ict = new Date(now.getTime() + 7 * 3600 * 1000);
      const day = ict.getUTCDay();
      const addDays = (5 - day + 7) % 7;
      let candidate = new Date(
        Date.UTC(ict.getUTCFullYear(), ict.getUTCMonth(), ict.getUTCDate() + addDays, 13, 0, 0)
      );
      if (candidate.getTime() <= now.getTime()) {
        candidate = new Date(candidate.getTime() + 7 * 86400000);
      }
      return candidate;
    }

    let target = nextFriday20ICT();
    function pad(value) {
      return String(value).padStart(2, "0");
    }
    function renderCountdown() {
      let diff = target.getTime() - Date.now();
      if (diff <= 0) {
        target = nextFriday20ICT();
        diff = target.getTime() - Date.now();
      }
      const totalSeconds = Math.floor(diff / 1000);
      const days = Math.floor(totalSeconds / 86400);
      const hours = Math.floor((totalSeconds % 86400) / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = totalSeconds % 60;
      if (daysEl) daysEl.textContent = pad(days);
      if (hoursEl) hoursEl.textContent = pad(hours);
      if (minutesEl) minutesEl.textContent = pad(minutes);
      if (secondsEl) secondsEl.textContent = pad(seconds);
    }
    renderCountdown();
    window.setInterval(renderCountdown, 1000);
  }

  /* FAQ: keep one answer open at a time */
  const faqItems = document.querySelectorAll(".faq-list .faq-item");
  faqItems.forEach(function (item) {
    item.addEventListener("toggle", function () {
      if (item.open) {
        faqItems.forEach(function (other) {
          if (other !== item) other.open = false;
        });
      }
    });
  });

  /* Support form (opens the visitor's email app) */
  const supportForm = document.getElementById("supportForm");
  if (supportForm) {
    supportForm.addEventListener("submit", function (event) {
      event.preventDefault();
      const name = document.getElementById("supportName");
      const username = document.getElementById("supportUsername");
      const contact = document.getElementById("supportContact");
      const topic = document.getElementById("supportTopic");
      const message = document.getElementById("supportMessage");
      if (!name || !username || !contact || !topic || !message) return;

      const topicLabel = topic.options[topic.selectedIndex] ? topic.options[topic.selectedIndex].text : topic.value;
      const subject = "ahrosora Support — " + topicLabel + " — " + username.value.trim();
      const body =
        "ឈ្មោះ: " + name.value.trim() + "\n" +
        "Minecraft: " + username.value.trim() + "\n" +
        "ទំនាក់ទំនង: " + contact.value.trim() + "\n" +
        "ប្រភេទបញ្ហា: " + topicLabel + "\n\n" +
        message.value.trim() + "\n\n" +
        "— ផ្ញើពី ahrosorashop.com/support.html";
      window.location.href =
        "mailto:support@luymea.com?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
      showToast("កំពុងបើកកម្មវិធីអ៊ីមែលរបស់អ្នក — សូមចុចផ្ញើ។");
    });
  }

  /* Newsletter (front-end demo) */
  const newsletterForm = document.getElementById("newsletterForm");
  if (newsletterForm) {
    newsletterForm.addEventListener("submit", function (event) {
      event.preventDefault();
      const input = document.getElementById("newsletterEmail");
      if (input && input.value.trim()) {
        showToast("អរគុណ! យើងនឹងផ្ញើព័ត៌មានថ្មីៗទៅ " + input.value.trim());
        newsletterForm.reset();
      }
    });
  }
})();
