/* ==========================================================================
   ahrosora — store / cart / checkout (front-end demo)
   ========================================================================== */
(function () {
  "use strict";

  const STORAGE_KEY = "luymea_cart_v1";
  const KHR_RATE = 4100;
  const TELEGRAM_URL = "https://t.me/ahrosoragp";

  const formatUSD = function (value) {
    return "$" + Number(value).toFixed(2);
  };
  const formatKHR = function (value) {
    const amount = Math.round(Number(value) * KHR_RATE);
    return "≈ " + new Intl.NumberFormat("en-US").format(amount) + " ៛";
  };

  /* ---------- Storage ---------- */
  let memoryCart = [];
  function loadCart() {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      return parsed
        .filter(function (item) {
          return item && typeof item.id === "string" && Number(item.price) >= 0;
        })
        .map(function (item) {
          return {
            id: item.id,
            name: String(item.name || "Item"),
            price: Number(item.price),
            icon: String(item.icon || "📦"),
            category: String(item.category || "items"),
            qty: Math.max(1, Math.min(99, parseInt(item.qty, 10) || 1))
          };
        });
    } catch (error) {
      return memoryCart.slice();
    }
  }
  function saveCart() {
    memoryCart = cart.slice();
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
    } catch (error) {
      /* storage may be unavailable; keep in memory */
    }
  }

  let cart = loadCart();

  /* ---------- DOM ---------- */
  const cartOpenBtn = document.getElementById("cartOpen");
  const cartDrawer = document.getElementById("cartDrawer");
  const cartOverlay = document.getElementById("cartOverlay");
  const cartClose = document.getElementById("cartClose");
  const cartItems = document.getElementById("cartItems");
  const cartEmpty = document.getElementById("cartEmpty");
  const cartTotal = document.getElementById("cartTotal");
  const cartKhr = document.getElementById("cartKhr");
  const cartCount = document.getElementById("cartCount");
  const cartCountText = document.getElementById("cartCountText");
  const checkoutBtn = document.getElementById("checkoutBtn");

  const checkoutModal = document.getElementById("checkoutModal");
  const checkoutClose = document.getElementById("checkoutClose");
  const checkoutFormWrap = document.getElementById("checkoutFormWrap");
  const checkoutSuccess = document.getElementById("checkoutSuccess");
  const checkoutForm = document.getElementById("checkoutForm");
  const checkoutSummary = document.getElementById("checkoutSummary");
  const orderCode = document.getElementById("orderCode");
  const successClose = document.getElementById("successClose");
  const mcUsername = document.getElementById("mcUsername");

  if (!cartDrawer || !checkoutModal) return;

  function escapeHTML(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function getTotals() {
    return cart.reduce(
      function (acc, item) {
        acc.usd += item.price * item.qty;
        acc.qty += item.qty;
        return acc;
      },
      { usd: 0, qty: 0 }
    );
  }

  function updateCartBadge() {
    const totals = getTotals();
    if (cartCount) {
      cartCount.textContent = String(totals.qty);
      cartCount.setAttribute("data-empty", totals.qty === 0 ? "true" : "false");
    }
    if (cartCountText) cartCountText.textContent = String(totals.qty);
  }

  function renderCart() {
    if (!cartItems) return;
    cartItems.innerHTML = cart
      .map(function (item) {
        return (
          '<div class="cart-item" data-id="' + escapeHTML(item.id) + '">' +
            '<div class="ci-icon" aria-hidden="true">' + escapeHTML(item.icon) + "</div>" +
            '<div class="ci-body">' +
              '<div class="ci-top">' +
                "<h4>" + escapeHTML(item.name) + "</h4>" +
                '<button class="ci-remove" data-remove="' + escapeHTML(item.id) + '" aria-label="លុប ' + escapeHTML(item.name) + '">' +
                  '<svg class="icon"><use href="#i-close"/></svg>' +
                "</button>" +
              "</div>" +
              '<div class="ci-price">' + formatUSD(item.price) + " / មួយ</div>" +
              '<div class="ci-bottom">' +
                '<div class="qty">' +
                  '<button data-qty="minus" data-id="' + escapeHTML(item.id) + '" aria-label="បន្ថយចំនួន">−</button>' +
                  "<span>" + item.qty + "</span>" +
                  '<button data-qty="plus" data-id="' + escapeHTML(item.id) + '" aria-label="បន្ថែមចំនួន">+</button>' +
                "</div>" +
                '<div class="ci-total">' + formatUSD(item.price * item.qty) + "</div>" +
              "</div>" +
            "</div>" +
          "</div>"
        );
      })
      .join("");

    const isEmpty = cart.length === 0;
    cartItems.hidden = isEmpty;
    if (cartEmpty) cartEmpty.classList.toggle("visible", isEmpty);

    const totals = getTotals();
    if (cartTotal) cartTotal.textContent = formatUSD(totals.usd);
    if (cartKhr) cartKhr.textContent = formatKHR(totals.usd);
    if (checkoutBtn) checkoutBtn.disabled = isEmpty;
    updateCartBadge();
  }

  function addToCart(dataset) {
    const id = dataset.id;
    if (!id) return;
    const existing = cart.find(function (item) {
      return item.id === id;
    });
    if (existing) {
      existing.qty = Math.min(99, existing.qty + 1);
    } else {
      cart.push({
        id: id,
        name: dataset.name || "Item",
        price: parseFloat(dataset.price) || 0,
        icon: dataset.icon || "📦",
        category: dataset.category || "items",
        qty: 1
      });
    }
    saveCart();
    renderCart();
    if (window.showToast) {
      window.showToast("បានបន្ថែម " + (dataset.name || "ទំនិញ") + " ទៅកន្ត្រក");
    }
  }

  /* Add buttons */
  document.addEventListener("click", function (event) {
    const addBtn = event.target.closest(".add-to-cart");
    if (addBtn) {
      addToCart(addBtn.dataset);
      return;
    }
    const removeBtn = event.target.closest("[data-remove]");
    if (removeBtn) {
      const id = removeBtn.getAttribute("data-remove");
      cart = cart.filter(function (item) {
        return item.id !== id;
      });
      saveCart();
      renderCart();
      return;
    }
    const qtyBtn = event.target.closest("[data-qty]");
    if (qtyBtn) {
      const id = qtyBtn.getAttribute("data-id");
      const item = cart.find(function (entry) {
        return entry.id === id;
      });
      if (!item) return;
      if (qtyBtn.getAttribute("data-qty") === "plus") item.qty = Math.min(99, item.qty + 1);
      else item.qty = Math.max(1, item.qty - 1);
      saveCart();
      renderCart();
    }
  });

  /* ---------- Scroll lock ---------- */
  function updateScrollLock() {
    const drawerOpen = cartDrawer.classList.contains("open");
    const modalOpen = checkoutModal.classList.contains("open");
    document.body.classList.toggle("no-scroll", drawerOpen || modalOpen);
  }

  /* ---------- Drawer ---------- */
  function openCart() {
    cartDrawer.classList.add("open");
    cartDrawer.setAttribute("aria-hidden", "false");
    cartOverlay.classList.add("open");
    updateScrollLock();
    const closeButton = cartDrawer.querySelector(".drawer-close");
    if (closeButton) closeButton.focus({ preventScroll: true });
  }
  function closeCart() {
    cartDrawer.classList.remove("open");
    cartDrawer.setAttribute("aria-hidden", "true");
    cartOverlay.classList.remove("open");
    updateScrollLock();
    if (cartOpenBtn) cartOpenBtn.focus({ preventScroll: true });
  }

  if (cartOpenBtn) cartOpenBtn.addEventListener("click", openCart);
  if (cartClose) cartClose.addEventListener("click", closeCart);
  if (cartOverlay) cartOverlay.addEventListener("click", closeCart);

  /* ---------- Checkout modal ---------- */
  function renderCheckoutSummary() {
    if (!checkoutSummary) return;
    const totals = getTotals();
    const rows = cart
      .map(function (item) {
        return (
          '<div class="sum-row"><span>' + escapeHTML(item.name) + " × " + item.qty +
          "</span><b>" + formatUSD(item.price * item.qty) + "</b></div>"
        );
      })
      .join("");
    checkoutSummary.innerHTML =
      rows +
      '<div class="sum-row total"><span>សរុប</span><b>' + formatUSD(totals.usd) + "</b></div>" +
      '<div class="sum-row"><span class="khr">ប្រហាក់ប្រហែល</span><span class="khr">' + formatKHR(totals.usd) + "</span></div>";
  }

  function openCheckout() {
    if (cart.length === 0) {
      if (window.showToast) window.showToast("កន្ត្រករបស់អ្នកនៅទទេ", "error");
      return;
    }
    closeCart();
    checkoutFormWrap.hidden = false;
    checkoutSuccess.hidden = true;
    checkoutForm.reset();
    renderCheckoutSummary();
    checkoutModal.classList.add("open");
    checkoutModal.setAttribute("aria-hidden", "false");
    updateScrollLock();
    window.setTimeout(function () {
      if (mcUsername) mcUsername.focus({ preventScroll: true });
    }, 120);
  }

  function closeCheckout() {
    checkoutModal.classList.remove("open");
    checkoutModal.setAttribute("aria-hidden", "true");
    updateScrollLock();
    if (checkoutBtn) checkoutBtn.focus({ preventScroll: true });
    window.setTimeout(function () {
      checkoutFormWrap.hidden = false;
      checkoutSuccess.hidden = true;
      checkoutForm.reset();
    }, 250);
  }

  if (checkoutBtn) checkoutBtn.addEventListener("click", openCheckout);
  if (checkoutClose) checkoutClose.addEventListener("click", closeCheckout);
  if (successClose) successClose.addEventListener("click", closeCheckout);
  checkoutModal.addEventListener("click", function (event) {
    if (event.target === checkoutModal) closeCheckout();
  });

  document.addEventListener("keydown", function (event) {
    if (event.key !== "Escape") return;
    if (checkoutModal.classList.contains("open")) closeCheckout();
    else if (cartDrawer.classList.contains("open")) closeCart();
  });

  /* ---------- Copy helper ---------- */
  async function copyOrder(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (error) {
      /* fall back */
    }
    try {
      const area = document.createElement("textarea");
      area.value = text;
      area.setAttribute("readonly", "");
      area.style.position = "fixed";
      area.style.opacity = "0";
      document.body.appendChild(area);
      area.select();
      area.setSelectionRange(0, area.value.length);
      const ok = document.execCommand("copy");
      area.remove();
      return ok;
    } catch (error) {
      return false;
    }
  }

  function makeOrderCode() {
    const now = new Date();
    const yy = String(now.getFullYear()).slice(-2);
    const mm = String(now.getMonth() + 1).padStart(2, "0");
    const dd = String(now.getDate()).padStart(2, "0");
    const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
    return "LM-" + yy + mm + dd + "-" + rand;
  }

  if (checkoutForm) {
    checkoutForm.addEventListener("submit", async function (event) {
      event.preventDefault();
      if (!checkoutForm.reportValidity()) return;
      if (cart.length === 0) {
        if (window.showToast) window.showToast("កន្ត្រករបស់អ្នកនៅទទេ", "error");
        return;
      }

      const username = (mcUsername ? mcUsername.value : "").trim();
      const platform = document.getElementById("platform") ? document.getElementById("platform").value : "Java";
      const paymentInput = checkoutForm.querySelector('input[name="payment"]:checked');
      const payment = paymentInput ? paymentInput.value : "KHQR";
      const note = document.getElementById("orderNote") ? document.getElementById("orderNote").value.trim() : "";
      const totals = getTotals();
      const code = makeOrderCode();

      const lines = cart.map(function (item) {
        return "- " + item.name + " × " + item.qty + " — " + formatUSD(item.price * item.qty);
      });
      const orderText =
        "ahrosora ORDER " + code + "\n" +
        "Minecraft: " + username + "\n" +
        "Platform: " + platform + "\n" +
        "Payment: " + payment + "\n" +
        "----------------------------\n" +
        lines.join("\n") + "\n" +
        "----------------------------\n" +
        "Total: " + formatUSD(totals.usd) + " (" + formatKHR(totals.usd) + ")\n" +
        (note ? "Note: " + note + "\n" : "") +
        "Server: ahrosora.paper\n" +
        "Please send this message to @ahrosoragp on Telegram to receive payment instructions.";

      window.open(TELEGRAM_URL, "_blank", "noopener");
      const copied = await copyOrder(orderText);

      if (orderCode) orderCode.textContent = code;
      checkoutFormWrap.hidden = true;
      checkoutSuccess.hidden = false;

      cart = [];
      saveCart();
      renderCart();

      if (window.showToast) {
        if (copied) window.showToast("បានចម្លងការបញ្ជាទិញ — សូមផ្ញើទៅ @ahrosoragp ក្នុង Telegram");
        else window.showToast("សូមចម្លងព័ត៌មានដោយដៃ ហើយផ្ញើទៅ @ahrosoragp", "error");
      }
    });
  }

  /* ---------- Filters ---------- */
  const filterButtons = document.querySelectorAll(".filter-btn");
  const rankSection = document.getElementById("rankSection");
  const productSection = document.getElementById("productSection");
  const productCards = document.querySelectorAll("#productSection .product-card");

  filterButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      const filter = button.getAttribute("data-filter");
      filterButtons.forEach(function (other) {
        other.classList.toggle("active", other === button);
      });

      if (rankSection) rankSection.hidden = filter !== "all" && filter !== "rank";
      if (productSection) productSection.hidden = filter === "rank";

      productCards.forEach(function (card) {
        const category = card.getAttribute("data-category");
        card.hidden = !(filter === "all" || category === filter);
      });
    });
  });

  /* ---------- Init ---------- */
  renderCart();
})();
