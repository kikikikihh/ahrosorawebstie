# ahrosora — Cambodia Minecraft Server Website

A fully responsive, Khmer-first marketing and store website for **ahrosora**, a Cambodian Minecraft server at **ahrosorashop.com**. Built as a zero-dependency static site (HTML + CSS + vanilla JS), so it can be hosted free on GitHub Pages, Cloudflare Pages, Netlify, or any web host.

---

## Pages

| File | Purpose |
| --- | --- |
| `index.html` | Landing page: hero, game modes, rank preview, server status, gallery, events, join steps, FAQ, CTA |
| `store.html` | Official store: ranks, coins, cosmetics, filters, cart drawer, checkout modal |
| `rules.html` | Server rules, punishment table, store policy, privacy policy |
| `support.html` | Support channels, contact form, payment guide, support hours, mini FAQ |
| `404.html` | Custom not-found page |

Supporting files: `css/style.css` (all styling), `js/main.js` (shared UI), `js/store.js` (cart/checkout), `assets/*.svg` (logo and custom Minecraft-style Khmer artwork), `CNAME`, `robots.txt`, `sitemap.xml`.

---

## Run locally

The site works by opening `index.html` directly, but a local web server gives the best results (clipboard permissions, fonts, etc.):

```bash
# Python 3
python -m http.server 8080

# Node.js
npx serve .
```

Then open <http://localhost:8080>.

---

## Deploy to ahrosorashop.com

### Option A — GitHub Pages

1. Create a GitHub repository and push this folder.
2. Repository **Settings → Pages → Build and deployment**: Source = *Deploy from a branch*, Branch = `main`, Folder = `/ (root)`.
3. The included `CNAME` file already points the site to `ahrosorashop.com`. Keep it.
4. In your domain registrar / Cloudflare DNS, add:
   - `A` records for `@` → GitHub Pages IPs: `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - (Optional) `AAAA` records for `@` → `2606:50c0:8000::153`, `2606:50c0:8001::153`, `2606:50c0:8002::153`, `2606:50c0:8003::153`
   - `CNAME` record for `www` → `<your-github-username>.github.io`
   - Remove any registrar "parking" A records or wildcard records that point to a placeholder page.
   - If your DNS provider is Cloudflare, set the `www` CNAME to **DNS only** (grey cloud) until HTTPS has been issued; apex stays as `A` records.
5. Enable **Enforce HTTPS** in GitHub Pages settings.

### Option B — Cloudflare Pages / Netlify

- **Cloudflare Pages:** connect the repo, framework preset = *None*, build output directory = `/` (root).
- **Netlify:** drag and drop the folder into Netlify, or set publish directory to `.`.
- Add `ahrosorashop.com` as a custom domain in the dashboard and follow the DNS instructions.
- `CNAME` is harmless on these platforms; delete it if your host complains.

### Domain checklist

- [ ] `ahrosorashop.com` resolves with HTTPS.
- [ ] Set `www.ahrosorashop.com` to redirect to the apex domain (or vice versa).
- [ ] Replace the canonical/OG URLs if you launch on a different domain.
- [ ] Submit `https://ahrosorashop.com/sitemap.xml` in Google Search Console.

---

## What is real vs. demo

This is a **front-end template**. Everything visual and interactive works, but no backend is included.

| Area | Current behaviour | To make it live |
| --- | --- | --- |
| Checkout | Validates the form, generates an order code, copies the order to the clipboard and opens Telegram `@ahrosoragp`. The cart clears after the order. | Connect a real checkout/payment backend (ABA KHQR, Bakong, Wing, ACLEDA) and store orders in a database. |
| Store products | Hard-coded in `store.html` with `data-id`, `data-name`, `data-price`, `data-icon` attributes. | Update prices/products, or render them from an API. |
| Newsletter | Shows a success toast only. | Connect Mailchimp/Brevo/Formspree or your own API. |
| Contact form | Opens the visitor's email client with a prefilled message to `support@luymea.com`. | Replace with Formspree, a serverless function, or a ticket system. |
| Server status / player counts | Static marketing numbers (`1,248`, `18 ms`, etc.). | Fetch live data from `api.mcsrvstat.us` or your own status endpoint. |
| Social links | Placeholders: `discord.gg/b2JGdApsY`, `t.me/ahrosoragp`, `facebook.com/luymea`, `tiktok.com/@luymea`. | Replace with your real accounts. |
| Payments | Payment names are shown as options only. No payment credentials or KHQR accounts are included. | Add official merchant details and verify receipts manually or via API. |

> ⚠️ The prices, offers, bank names and server statistics are placeholders. Replace them before publishing for real customers.

---

## Customisation

- **Server IP / ports:** search for `ahrosora.paper` and `19132` across the HTML files.
- **Colours:** edit the design tokens at the top of `css/style.css` (`--emerald`, `--gold`, backgrounds, fonts).
- **Fonts:** Google Fonts — *Kantumruy Pro* (Khmer body), *Moul* (Khmer display), *Space Grotesk* (Latin), *Silkscreen* (pixel accents).
- **Logo / favicon:** `assets/logo.svg`.
- **Artwork:** `assets/hero-world.svg`, `scene-angkor.svg`, `scene-survival.svg`, `scene-bedwars.svg` — all hand-built SVG, no external images.
- **Rank content:** duplicated on `index.html` and `store.html`; keep both in sync.
- **Meta / SEO:** update titles, descriptions, canonical URLs, and the JSON-LD block in `index.html`.
- **Social preview:** OG image currently points to an SVG. For best compatibility on Facebook/Discord/X, export a **1200×630 PNG** and update the `og:image` / `twitter:image` tags.

---

## Cart & checkout logic

- Cart is stored in `localStorage` under `luymea_cart_v1`.
- Prices are USD; KHR estimates use a fixed rate of **4,100 KHR/USD** in `js/store.js` (`KHR_RATE`). Update it to your live rate.
- Order codes use the format `LM-YYMMDD-XXXX`.
- Checkout is a **demo handoff**: the order summary is copied to the clipboard and Telegram is opened. No card data, bank credentials, or OTPs are collected by the site.
- Staff should never ask for a customer's Minecraft password or OTP — this is stated on the rules page.

---

## Accessibility & performance

- Semantic landmarks, skip link, visible focus states, ARIA labels on interactive controls.
- Mobile navigation, keyboard `Escape` handling, focus return, and body scroll locking for the cart/modal.
- `prefers-reduced-motion` support.
- No frameworks, no build step. The only external request is Google Fonts.
- All artwork is SVG, so the site stays crisp on every screen.

---

## Legal

ahrosora is not affiliated with Mojang Studios or Microsoft. Minecraft is a trademark of Mojang Synergies AB. The footer disclaimer is included on every page — keep it. Replace the placeholder store policy and privacy text with wording reviewed for your business before accepting real payments.

---

© 2026 ahrosora · ahrosorashop.com
